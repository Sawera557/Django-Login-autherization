from django.shortcuts import render, redirect
from .forms import RegisterForm
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import logout


# Create your views here.
def register(response):
    if response.method == "POST":
        form = RegisterForm(response.POST)
        if form.is_valid():
            form.save()

        return redirect("/portfolio")
    else:
        form = RegisterForm()

    return render(response, "register/register.html", {'form': form})


def login(response):
    if response.method == "POST":
        form = RegisterForm(response.POST)
        if form.is_valid():
            form.save()

        return redirect("/portfolio")
    else:
        form = RegisterForm()

    return render(response, "register/login.html", {'form': form})


def logout_view(request):
    logout(request)
    #return redirect(request, "register/logged_out.html")


def admin_dashboard(request):
    if not request.user.is_authenticated():
        return redirect('/home')
    else:
        return redirect('/admin')

